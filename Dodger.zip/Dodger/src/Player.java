import java.awt.event.*;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Player extends JPanel implements ActionListener, KeyListener{
	Timer t = new Timer(5,this);
	public int x=500, y=650;
	double velx =0, vely=0;
	
	public void player(){
		t.start();
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
	}
	
	public void actionPerformed(){
		repaint();
		x += velx;
		y += vely;
	}
	 public void up(){
	        vely = -1.5;
	        velx = 0;
	    }

	    public void down(){
	        vely = 1.5;
	        velx = 0;
	    }

	    public void left(){
	        velx = -1.5;
	        vely = 0;
	    }

	    public void right(){
	        velx = 1.5;
	        vely = 0;
	    }
	//@Override
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		public void paint(Graphics g){
	        g.setColor(Color.RED);
	        actionPerformed();
	        g.fillRect(x,y,25,25);
	       // t.start();
		}
}
