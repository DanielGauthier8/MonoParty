import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DodgerGame extends JPanel implements ActionListener, KeyListener {
	//Sets window size
    public static final int WINDOW_WIDTH = 1000;
    public static final int WINDOW_HEIGHT = 750;

    //Creates a GameObject (squares) object Array
    GameObject[] squareArray = new GameObject[25];
    Player player = new Player();

    public static void main(String[] args) throws InterruptedException {
        DodgerGame game = new DodgerGame();
        JFrame frame = new JFrame();		//creates new jframe
        frame.add(game);
        frame.setVisible(true);
        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setTitle("Dodger Mini Game");
        frame.setResizable(false);
        //frame.setLocationRelativeTo(null);

        while (true) {
            game.fallingUpdate();
            game.repaint();
            Thread.sleep(10);
        }
    }
    
    public DodgerGame() {
        //initializes square objects
        for (int i = 0; i < squareArray.length; i++)
            squareArray[i] = new GameObject();
    }

    public void fallingUpdate() {
        //calls the GameObject class update method
        for (GameObject aSquareArray : squareArray) 
        	aSquareArray.update();
    }
    public void keyPressed(KeyEvent e) {
		int code = e.getKeyCode();

        if (code == KeyEvent.VK_UP){
            player.up();
        }

        if (code == KeyEvent.VK_DOWN){
            player.down();
        }

        if (code == KeyEvent.VK_LEFT){
            player.left();
        }

        if (code == KeyEvent.VK_RIGHT){
            player.right();
        }
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		//int code = e.getKeyCode();

        //if (code == KeyEvent.VK_UP){
          //  vely = 0;
        //}
        //if (code == KeyEvent.VK_DOWN){
         //   vely = 0;
        //}
        //if (code == KeyEvent.VK_LEFT){
         //   velx = 0;
        //}
        //if (code == KeyEvent.VK_RIGHT){
          //  velx = 0;
        //}
		
	}
   // public void playerUpdate(ActionEvent e) {
    //	player.actionPerformed(e);
    //}
    public void paint(Graphics graphics) {
        //makes background black
        graphics.setColor(Color.black);
        graphics.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        //paints square objects to the screen
        for (GameObject aSquareArray : squareArray) {
            aSquareArray.paint(graphics);
        }
        player.paint(graphics);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}

