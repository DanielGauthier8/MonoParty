	import javax.swing.*;
	import java.awt.*;
	import java.util.Random;

	public class GameObject extends JPanel {

	    private int squareXLocation;
	    private int squareSize;
	    private int squareYLocation = -squareSize;
	    private int fallSpeed = 1;
	    Random rand = new Random();
	    private int difficulty = 2;
	    
	    /*
	    sets the squareWidth and square fallSpeed to a random value for every square created
	    */
	    public GameObject(){
	        generateRandomXLocation();
	        generateRandomSquareSize();
	        generateRandomFallSpeed();
	    }
	    /*
	    creates a random value inside the window and stores it in squareXLocation
	    */
	    public int generateRandomXLocation(){
	        return squareXLocation = rand.nextInt(DodgerGame.WINDOW_WIDTH - squareSize);
	    }

	    /*
	    creates a random value between 1-50 and stores it in squareWidth
	    */
	    public int generateRandomSquareSize(){
	        //return squareSize = rand.nextInt(50);
	    		//if (difficulty == 1){
	    			squareSize = rand.ints(40, 40, 60).findFirst().getAsInt();
		    	//}
		    	//else if(difficulty == 2){
		    //		squareSize = rand.ints(25, 25, 75).findFirst().getAsInt();
		    	//}
		    	//else if(difficulty == 3){
		    //		squareSize = rand.ints(25, 25, 100).findFirst().getAsInt();
		    	//}
	    	return squareSize;
	    }

	    /*
	    creates a random value and stores it in fallSpeed
	    */
	    public int generateRandomFallSpeed(){
	    	if (difficulty == 1){
	        //fallSpeed = 1;
	    		fallSpeed = rand.ints(4, 4, 6).findFirst().getAsInt();
	    	}
	    	else if(difficulty == 2){
	    		fallSpeed = rand.ints(6, 6, 10).findFirst().getAsInt();
	    	}
	    	else if(difficulty == 3){
	    		fallSpeed = rand.ints(8, 8, 11).findFirst().getAsInt();
	    	}
	    	return fallSpeed;
	    }


	    public void update(){
	        //changes the squares xLocation and fallSpeed if the created square reaches the bottom of the screen
	        if(squareYLocation >= DodgerGame.WINDOW_HEIGHT){
	            generateRandomXLocation();
	            generateRandomFallSpeed();
	            generateRandomSquareSize();
	            squareYLocation = -squareSize;
	        }
	        //moves the square down if the square is inside the window
	        if(squareYLocation <= DodgerGame.WINDOW_HEIGHT){
	            squareYLocation += fallSpeed;
	        }
	    }
	    
	    /*
	    paints the square with the variables generated in the random methods
	    */
	    public void paint(Graphics g){
	        //g.setColor(Color.CYAN);
	    	g.setColor(Color.GREEN);
	        g.fillRect(squareXLocation,squareYLocation,squareSize,squareSize);
	    }
}
