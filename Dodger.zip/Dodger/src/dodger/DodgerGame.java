package dodger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.Instant;

public class DodgerGame extends JPanel implements ActionListener, KeyListener {
    //Sets window size
    public static final int WINDOW_WIDTH = 1280;
    public static final int WINDOW_HEIGHT = 720;

    //Creates a GameObject (squares) object Array
    static GameObject[] squareArray = new GameObject[30];
    static Player player;
    private static int points = 0;

    public static void main(String[] args) throws InterruptedException {
        DodgerGame game = new DodgerGame();
        JFrame frame = new JFrame();		//creates new jframe
        frame.add(game);
        frame.setVisible(true);
        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setTitle("Dodger Mini Game");
        frame.setResizable(false);
        //frame.setLocationRelativeTo(null);
        
        Instant instant = Instant.now();
        long invulTimeStamp = 0;
        long currentTime = 0;
        
        while (player.getLives() > 0) {
            while(currentTime - invulTimeStamp < 3) {
                instant = Instant.now();
                currentTime = instant.getEpochSecond();
                game.fallingUpdate();
                game.repaint();
                Thread.sleep(10);
            }
            
            player.setInvulnerable(false);
            player.setColor(Color.red);
            
            while(!player.getInvulnerable()) {
                for(int i=0; i < squareArray.length; i++) {
                    if(squareArray[i].collisionDetection(player)) {
                        player.subtractLife();
                        player.setInvulnerable(true);
                        invulTimeStamp = instant.getEpochSecond();
                        instant = Instant.now();
                        player.setColor(Color.gray);
                        break;
                    }
                }
                pointDetection();
                game.fallingUpdate();
                game.repaint();
                Thread.sleep(10);
            }
        }
        System.out.println(points);
    }
    
    public DodgerGame() {
        //initializes square objects
    	player = new Player(KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_LEFT,KeyEvent.VK_RIGHT);
        Timer timer = new Timer(5, this);
        timer.start();
        addKeyListener(this);
        setFocusable(true);
        for (int i = 0; i < squareArray.length; i++)
            squareArray[i] = new GameObject();
    }

    public void fallingUpdate() {
        //calls the GameObject class update method
        for (GameObject aSquareArray : squareArray) 
        	aSquareArray.update();
    }
    
    public static void pointDetection() {
        for(int i=0; i < squareArray.length; i++) {
            if(squareArray[i].getBottomLocation() > WINDOW_HEIGHT) {
                points++;
            }
        }
    }
    
    private void update(){
    	player.update();
    }
    public void actionPerformed(ActionEvent e) {
        update();
        //repaint();
        player.repaint();
    }

    public void keyPressed(KeyEvent e) {
        player.pressed(e.getKeyCode());
    }

    public void keyReleased(KeyEvent e) {
        player.released(e.getKeyCode());
    }
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
	}
    public void paint(Graphics graphics) {
        //makes background black
        graphics.setColor(Color.black);
        graphics.fillRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        //paints square objects to the screen
        for (GameObject aSquareArray : squareArray) {
            aSquareArray.paint(graphics);
        }
        player.paint(graphics);
    }


}

